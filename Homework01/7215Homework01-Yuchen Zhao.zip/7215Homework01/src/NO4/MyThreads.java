package NO4;

import java.util.ArrayList;

public class MyThreads implements Runnable {

	ArrayList<Integer> integer = new ArrayList<Integer>();
	
	public MyThreads() {
		// TODO Auto-generated constructor stub
	}
	
	public synchronized void m1() {
		
	}

	@Override
	public void run() {
		
	}

}
