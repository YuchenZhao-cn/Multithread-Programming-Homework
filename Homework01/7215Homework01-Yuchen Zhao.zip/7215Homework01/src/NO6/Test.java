package NO6;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		I a = new A();
		a.m1();
		a.m2();
		a.m3();
		a.m4();
	}

}
