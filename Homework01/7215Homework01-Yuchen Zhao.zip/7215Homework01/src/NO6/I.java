package NO6;

public interface I extends I1,I2{
	
}
