package NO6;

public interface I1 {
	
	public void m1();
	public void m2();

}
