package NO6;

public interface I2 {
	
	public void m3();
	public void m4();

}
