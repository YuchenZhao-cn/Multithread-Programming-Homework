package NO6;

public class A implements I{

	public A() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void m1() {
		System.out.println("m1()");
	}

	@Override
	public void m2() {
		System.out.println("m2()");
	}

	@Override
	public void m3() {
		System.out.println("m3()");
	}

	@Override
	public void m4() {
		System.out.println("m4()");
	}

}
